package com.adhoorelafzon.shayari;
import android.app.*; import android.os.*; import android.widget.*; import java.util.*;
public class MainActivity extends Activity {
 EditText shayari; TextView status; Spinner mood;
 String[] moods={"Sad","Romantic"};
 String[] sad={"Kuch log yaadon mein reh jaate hain,\nmagar zindagi se chale jaate hain...","Raat khamosh thi, dil udaas tha,\nteri yaadon ka phir se ehsaas tha..."};
 String[] romantic={"Tere saath hoon to har pal khaas lagta hai,\ntumse hi mera har khwaab paas lagta hai...","Mohabbat lafzon se nahi, ehsaas se hoti hai,\ntum paas ho to har shaam khaas hoti hai..."};
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  mood=findViewById(R.id.mood); shayari=findViewById(R.id.shayari); status=findViewById(R.id.status);
  mood.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,moods));
  findViewById(R.id.generate).setOnClickListener(v->{Random r=new Random();String[] a=mood.getSelectedItemPosition()==0?sad:romantic;shayari.setText(a[r.nextInt(a.length)]);status.setText("Status: Shayari ready — approval ka wait hai.");});
  findViewById(R.id.approve).setOnClickListener(v->status.setText("Status: Approved ✓"));
  findViewById(R.id.voice).setOnClickListener(v->status.setText("Status: Voice step ready — ElevenLabs/provider backend se connect hoga."));
  findViewById(R.id.video).setOnClickListener(v->status.setText("Status: Video pipeline — 9:16 + subtitles + permanent branding."));
  findViewById(R.id.publish).setOnClickListener(v->status.setText("Status: Publishing connectors — YouTube, Instagram & Facebook."));
 }
}