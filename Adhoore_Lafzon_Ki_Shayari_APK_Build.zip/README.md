# Adhoore Lafzon Ki Shayari — Android v3
Android source project for the mobile-first Shayari workflow.
Generate/approve Shayari → voice → 9:16 video → publish.
Permanent branding: Adhoore Lafzon Ki Shayari.
This ZIP is source code, not a compiled APK. Real voice generation and social publishing require secure backend/API credentials and OAuth approvals.